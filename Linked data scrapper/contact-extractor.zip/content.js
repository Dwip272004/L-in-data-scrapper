// content.js - Extracts LinkedIn profile data
(function() {
    'use strict';

    function extractProfileData() {
        console.log('Starting profile extraction...');
        
        const profileData = {
            name: '',
            headline: '',
            location: '',
            about: '',
            experience: [],
            education: [],
            skills: [],
            contactInfo: {
                email: '',
                phone: '',
                website: '',
                linkedinUrl: window.location.href
            },
            profileImage: '',
            connections: ''
        };

        // Extract name - Updated selectors for current LinkedIn
        const nameSelectors = [
            'h1.text-heading-xlarge.inline.t-24.v-align-middle.break-words',
            'h1.text-heading-xlarge',
            '.pv-text-details__left-panel h1',
            '.mt2.relative h1',
            'main section .mt2 h1',
            '.pv-top-card .pv-top-card__content .pv-text-details__left-panel h1'
        ];
        
        for (const selector of nameSelectors) {
            const nameEl = document.querySelector(selector);
            if (nameEl && nameEl.textContent.trim()) {
                profileData.name = nameEl.textContent.trim();
                console.log('Found name:', profileData.name);
                break;
            }
        }

        // Extract headline - More comprehensive selectors
        const headlineSelectors = [
            '.text-body-medium.break-words',
            '.pv-text-details__left-panel .text-body-medium',
            'main section .mt2 .text-body-medium.break-words',
            '.pv-top-card .pv-top-card__content .pv-text-details__left-panel .text-body-medium',
            '.pv-top-card__headline'
        ];
        
        for (const selector of headlineSelectors) {
            const headlineEl = document.querySelector(selector);
            if (headlineEl && headlineEl.textContent.trim() && 
                headlineEl.textContent.trim() !== profileData.name) {
                profileData.headline = headlineEl.textContent.trim();
                console.log('Found headline:', profileData.headline);
                break;
            }
        }

        // Extract location - Updated selectors
        const locationSelectors = [
            '.text-body-small.inline.t-black--light.break-words',
            '.pv-text-details__left-panel .text-body-small',
            'main section .mt2 .text-body-small.inline.t-black--light.break-words',
            '.pv-top-card .pv-top-card__content .pv-text-details__left-panel .text-body-small'
        ];
        
        for (const selector of locationSelectors) {
            const locationEl = document.querySelector(selector);
            if (locationEl && locationEl.textContent.trim()) {
                profileData.location = locationEl.textContent.trim();
                console.log('Found location:', profileData.location);
                break;
            }
        }

        // Extract profile image - Updated selectors
        const imageSelectors = [
            '.pv-top-card-profile-picture__image--show img',
            '.pv-top-card-profile-picture__image',
            'img.pv-top-card-profile-picture__image',
            '.profile-photo-edit__preview',
            'img[data-delayed-url*="profile-displayphoto"]',
            '.pv-top-card__photo img'
        ];
        
        for (const selector of imageSelectors) {
            const imageEl = document.querySelector(selector);
            if (imageEl) {
                profileData.profileImage = imageEl.src || imageEl.getAttribute('data-delayed-url') || '';
                console.log('Found profile image:', profileData.profileImage);
                break;
            }
        }

        // Extract connections count
        const connectionsSelectors = [
            '.pv-top-card--list li button span.t-bold',
            '.pv-top-card--list-bullet .t-bold',
            '.pv-top-card__connections-count',
            '.pv-top-card--list-bullet span.t-bold'
        ];
        
        for (const selector of connectionsSelectors) {
            const connectionsEl = document.querySelector(selector);
            if (connectionsEl && (connectionsEl.textContent.includes('connection') || 
                                connectionsEl.textContent.includes('follower'))) {
                profileData.connections = connectionsEl.textContent.trim();
                console.log('Found connections:', profileData.connections);
                break;
            }
        }

        // Extract about section - Updated selectors
        const aboutSelectors = [
            '#about ~ * .inline-show-more-text span[aria-hidden="true"]',
            '.pv-about-section .inline-show-more-text span[aria-hidden="true"]',
            '#about + * .pv-shared-text-with-see-more span[aria-hidden="true"]',
            '.pv-about-section .pv-shared-text-with-see-more span',
            '[data-section="summary"] .pv-shared-text-with-see-more span[aria-hidden="true"]',
            '.core-section-container__content .pv-about-section span[aria-hidden="true"]'
        ];
        
        for (const selector of aboutSelectors) {
            const aboutEl = document.querySelector(selector);
            if (aboutEl && aboutEl.textContent.trim()) {
                profileData.about = aboutEl.textContent.trim();
                console.log('Found about section');
                break;
            }
        }

        // Extract experience - Updated selectors
        const experienceSelectors = [
            '#experience ~ * .pvs-list__item--line-separated',
            '.pv-profile-section.experience-section',
            '[data-section="experience"]',
            '#experience'
        ];
        
        for (const selector of experienceSelectors) {
            const experienceSection = document.querySelector(selector);
            if (experienceSection) {
                const experienceItems = experienceSection.querySelectorAll(
                    '.pvs-list__item--line-separated, .pv-entity__summary-info, .pv-experience-section__company-group, .pvs-entity'
                );
                
                experienceItems.forEach(item => {
                    const titleSelectors = [
                        '.mr1.t-bold span[aria-hidden="true"]',
                        '.pvs-entity__caption-wrapper .mr1.t-bold',
                        'h3 span[aria-hidden="true"]',
                        '.pv-entity__summary-info h3',
                        '.pvs-entity__path-node h3'
                    ];
                    
                    const companySelectors = [
                        '.t-14.t-normal span[aria-hidden="true"]',
                        '.pv-entity__secondary-title',
                        '.pvs-entity__caption-wrapper .t-14.t-normal'
                    ];
                    
                    const dateSelectors = [
                        '.pvs-entity__caption-wrapper .t-black--light span[aria-hidden="true"]',
                        '.pv-entity__date-range',
                        '.pv-entity__bullet-item-v2'
                    ];
                    
                    let title = '', company = '', duration = '';
                    
                    for (const sel of titleSelectors) {
                        const titleEl = item.querySelector(sel);
                        if (titleEl && titleEl.textContent.trim()) {
                            title = titleEl.textContent.trim();
                            break;
                        }
                    }
                    
                    for (const sel of companySelectors) {
                        const companyEl = item.querySelector(sel);
                        if (companyEl && companyEl.textContent.trim()) {
                            company = companyEl.textContent.trim();
                            break;
                        }
                    }
                    
                    for (const sel of dateSelectors) {
                        const dateEl = item.querySelector(sel);
                        if (dateEl && dateEl.textContent.trim()) {
                            duration = dateEl.textContent.trim();
                            break;
                        }
                    }
                    
                    if (title) {
                        profileData.experience.push({
                            title: title,
                            company: company,
                            duration: duration
                        });
                    }
                });
                
                if (profileData.experience.length > 0) {
                    console.log('Found experience:', profileData.experience.length, 'items');
                    break;
                }
            }
        }

        // Extract education - Updated selectors
        const educationSelectors = [
            '#education ~ * .pvs-list__item--line-separated',
            '.pv-profile-section.education-section',
            '[data-section="education"]',
            '#education'
        ];
        
        for (const selector of educationSelectors) {
            const educationSection = document.querySelector(selector);
            if (educationSection) {
                const educationItems = educationSection.querySelectorAll(
                    '.pvs-list__item--line-separated, .pv-entity__summary-info, .pvs-entity'
                );
                
                educationItems.forEach(item => {
                    const schoolEl = item.querySelector('.mr1.t-bold span[aria-hidden="true"], h3 span[aria-hidden="true"], .pv-entity__school-name');
                    const degreeEl = item.querySelector('.t-14.t-normal span[aria-hidden="true"], .pv-entity__degree-name');
                    const dateEl = item.querySelector('.pvs-entity__caption-wrapper .t-black--light span[aria-hidden="true"], .pv-entity__dates');
                    
                    if (schoolEl && schoolEl.textContent.trim()) {
                        profileData.education.push({
                            school: schoolEl.textContent.trim(),
                            degree: degreeEl ? degreeEl.textContent.trim() : '',
                            dates: dateEl ? dateEl.textContent.trim() : ''
                        });
                    }
                });
                
                if (profileData.education.length > 0) {
                    console.log('Found education:', profileData.education.length, 'items');
                    break;
                }
            }
        }

        // Extract skills - Updated selectors
        const skillsSelectors = [
            '#skills ~ * .pvs-list__item--line-separated',
            '.pv-profile-section.pv-skill-categories-section',
            '[data-section="skills"]',
            '#skills'
        ];
        
        for (const selector of skillsSelectors) {
            const skillsSection = document.querySelector(selector);
            if (skillsSection) {
                const skillItems = skillsSection.querySelectorAll(
                    '.mr1.t-bold span[aria-hidden="true"], .pv-skill-category-entity__name span, .pvs-entity__path-node span[aria-hidden="true"]'
                );
                
                skillItems.forEach(skill => {
                    const skillText = skill.textContent.trim();
                    if (skillText && !profileData.skills.includes(skillText)) {
                        profileData.skills.push(skillText);
                    }
                });
                
                console.log('Found skills:', profileData.skills.length, 'items');
                break;
            }
        }

        // If no skills found, try alternative approach
        if (profileData.skills.length === 0) {
            const allSkillElements = document.querySelectorAll('span[aria-hidden="true"]');
            const skillKeywords = ['JavaScript', 'Python', 'React', 'Node', 'HTML', 'CSS', 'Java', 'C++', 'SQL', 'MongoDB', 'AWS', 'Docker', 'Git'];
            
            allSkillElements.forEach(el => {
                const text = el.textContent.trim();
                if (skillKeywords.some(keyword => text.includes(keyword)) && 
                    !profileData.skills.includes(text) && text.length < 50) {
                    profileData.skills.push(text);
                }
            });
        }

        // Extract contact information - Enhanced version
        
        // LinkedIn URL (always available)
        profileData.contactInfo.linkedinUrl = window.location.href;
        
        // Extract website/portfolio links from about section or contact info
        const websiteSelectors = [
            'a[href*="http"]:not([href*="linkedin.com"])',
            '.pv-contact-info__contact-type a',
            '.pv-about-section a[href*="http"]:not([href*="linkedin.com"])'
        ];
        
        const websites = new Set();
        for (const selector of websiteSelectors) {
            const links = document.querySelectorAll(selector);
            links.forEach(link => {
                const href = link.href;
                if (href && !href.includes('linkedin.com') && !href.includes('javascript:')) {
                    websites.add(href);
                }
            });
        }
        profileData.contactInfo.websites = Array.from(websites);
        
        // Try to extract email from contact info section (if available)
        const emailSelectors = [
            '.pv-contact-info__contact-type[data-section="email"] a',
            'a[href^="mailto:"]'
        ];
        
        for (const selector of emailSelectors) {
            const emailEl = document.querySelector(selector);
            if (emailEl) {
                const email = emailEl.href ? emailEl.href.replace('mailto:', '') : emailEl.textContent.trim();
                if (email.includes('@')) {
                    profileData.contactInfo.email = email;
                    break;
                }
            }
        }
        
        // Try to extract phone from contact info section (if available)
        const phoneSelectors = [
            '.pv-contact-info__contact-type[data-section="phoneNumbers"] span',
            'a[href^="tel:"]'
        ];
        
        for (const selector of phoneSelectors) {
            const phoneEl = document.querySelector(selector);
            if (phoneEl) {
                const phone = phoneEl.href ? phoneEl.href.replace('tel:', '') : phoneEl.textContent.trim();
                if (phone && phone.match(/[\d\+\-\(\)\s]/)) {
                    profileData.contactInfo.phone = phone;
                    break;
                }
            }
        }
        
        // Extract social media links
        const socialSelectors = [
            'a[href*="twitter.com"]',
            'a[href*="github.com"]',
            'a[href*="instagram.com"]',
            'a[href*="facebook.com"]',
            'a[href*="youtube.com"]',
            'a[href*="behance.net"]',
            'a[href*="dribbble.com"]'
        ];
        
        const socialLinks = {};
        socialSelectors.forEach(selector => {
            const link = document.querySelector(selector);
            if (link) {
                const platform = link.href.match(/(?:https?:\/\/(?:www\.)?)([\w-]+)\./)?.[1] || 'unknown';
                socialLinks[platform] = link.href;
            }
        });
        profileData.contactInfo.socialLinks = socialLinks;
        
        // Extract company email pattern from current job (if available)
        if (profileData.experience.length > 0) {
            const currentJob = profileData.experience[0];
            if (currentJob.company) {
                // Try to guess company domain (this is just for information, not actual email)
                const companyName = currentJob.company.toLowerCase()
                    .replace(/[^a-z0-9]/g, '')
                    .replace(/(inc|ltd|llc|corp|company|technologies|tech|solutions)$/g, '');
                profileData.contactInfo.companyDomain = `${companyName}.com (estimated)`;
            }
        }

        console.log('Contact info extracted:', profileData.contactInfo);
    }

    // Listen for messages from popup
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === 'extractProfile') {
            try {
                const data = extractProfileData();
                sendResponse({ success: true, data: data });
            } catch (error) {
                sendResponse({ success: false, error: error.message });
            }
        }
        return true; // Keep message channel open for async response
    });

    // Auto-extract when page loads and store in chrome.storage
    function autoExtract() {
        const data = extractProfileData();
        if (data.name) {
            chrome.storage.local.set({ linkedinProfileData: data });
        }
    }

    // Run extraction after page loads
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', autoExtract);
    } else {
        // Wait a bit for dynamic content to load
        setTimeout(autoExtract, 2000);
    }

    // Also run when URL changes (for SPA navigation)
    let currentUrl = window.location.href;
    const observer = new MutationObserver(() => {
        if (currentUrl !== window.location.href) {
            currentUrl = window.location.href;
            setTimeout(autoExtract, 2000);
        }
    });
    observer.observe(document.body, { childList: true, subtree: true });

})();