// popup.js
document.addEventListener('DOMContentLoaded', function() {
    loadProfileData();
});

function showSection(sectionId) {
    document.getElementById('loading').style.display = 'none';
    document.getElementById('error').style.display = 'none';
    document.getElementById('no-data').style.display = 'none';
    document.getElementById('profile-data').style.display = 'none';
    
    document.getElementById(sectionId).style.display = 'block';
}

function loadProfileData() {
    // First try to load from storage
    chrome.storage.local.get(['linkedinProfileData'], function(result) {
        if (result.linkedinProfileData && result.linkedinProfileData.name) {
            displayProfileData(result.linkedinProfileData);
        } else {
            // If no stored data, try to extract from current page
            extractProfile();
        }
    });
}

function extractProfile() {
    showSection('loading');
    
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        const currentTab = tabs[0];
        
        // Check if we're on a LinkedIn profile page
        if (!currentTab.url.includes('linkedin.com/in/')) {
            showSection('no-data');
            return;
        }
        
        // First try to inject the content script if needed
        chrome.scripting.executeScript({
            target: { tabId: currentTab.id },
            files: ['content.js']
        }).then(() => {
            // Wait a moment for the script to load, then send message
            setTimeout(() => {
                chrome.tabs.sendMessage(currentTab.id, { action: 'extractProfile' }, function(response) {
                    if (chrome.runtime.lastError) {
                        console.error('Message error:', chrome.runtime.lastError);
                        showSection('error');
                        return;
                    }
                    
                    if (response && response.success && response.data) {
                        console.log('Extracted data:', response.data);
                        displayProfileData(response.data);
                        // Store the data for future use
                        chrome.storage.local.set({ linkedinProfileData: response.data });
                    } else {
                        console.error('Extraction failed:', response);
                        showSection('error');
                    }
                });
            }, 1000);
        }).catch(error => {
            // Content script might already be injected, try sending message anyway
            console.log('Script injection failed, trying message anyway:', error);
            chrome.tabs.sendMessage(currentTab.id, { action: 'extractProfile' }, function(response) {
                if (chrome.runtime.lastError) {
                    console.error('Message error:', chrome.runtime.lastError);
                    showSection('error');
                    return;
                }
                
                if (response && response.success && response.data) {
                    console.log('Extracted data:', response.data);
                    displayProfileData(response.data);
                    // Store the data for future use
                    chrome.storage.local.set({ linkedinProfileData: response.data });
                } else {
                    console.error('Extraction failed:', response);
                    showSection('error');
                }
            });
        });
    });
}

function displayProfileData(data) {
    showSection('profile-data');
    
    // Profile header
    document.getElementById('profile-name').textContent = data.name || 'Unknown';
    document.getElementById('profile-headline').textContent = data.headline || 'No headline available';
    
    // Profile image
    const profileImage = document.getElementById('profile-image');
    const placeholder = document.getElementById('profile-image-placeholder');
    
    if (data.profileImage) {
        profileImage.src = data.profileImage;
        profileImage.style.display = 'block';
        placeholder.style.display = 'none';
        
        profileImage.onerror = function() {
            profileImage.style.display = 'none';
            placeholder.style.display = 'flex';
        };
    } else {
        profileImage.style.display = 'none';
        placeholder.style.display = 'flex';
    }
    
    // Location
    const locationElement = document.getElementById('profile-location').querySelector('span:last-child');
    locationElement.textContent = data.location || 'Location not specified';
    
    // Connections
    const connectionsElement = document.getElementById('profile-connections');
    if (data.connections) {
        connectionsElement.style.display = 'flex';
        connectionsElement.querySelector('span:last-child').textContent = data.connections;
    }
    
    // About section
    const aboutSection = document.getElementById('about-section');
    const aboutText = document.getElementById('about-text');
    if (data.about && data.about.trim()) {
        aboutText.textContent = data.about;
        aboutSection.style.display = 'block';
    }
    
    // Experience section
    const experienceSection = document.getElementById('experience-section');
    const experienceList = document.getElementById('experience-list');
    if (data.experience && data.experience.length > 0) {
        experienceList.innerHTML = '';
        data.experience.forEach(exp => {
            const expDiv = document.createElement('div');
            expDiv.className = 'experience-item';
            expDiv.innerHTML = `
                <div class="job-title">${exp.title || 'Position not specified'}</div>
                <div class="company-name">${exp.company || 'Company not specified'}</div>
                <div class="job-duration">${exp.duration || ''}</div>
            `;
            experienceList.appendChild(expDiv);
        });
        experienceSection.style.display = 'block';
    }
    
    // Skills section
    const skillsSection = document.getElementById('skills-section');
    const skillsList = document.getElementById('skills-list');
    if (data.skills && data.skills.length > 0) {
        skillsList.innerHTML = '';
        data.skills.forEach(skill => {
            const skillTag = document.createElement('div');
            skillTag.className = 'skill-tag';
            skillTag.textContent = skill;
            skillsList.appendChild(skillTag);
        });
        skillsSection.style.display = 'block';
    }
    
    // Contact information section
    const contactSection = document.getElementById('contact-section');
    const contactInfo = data.contactInfo || {};
    let hasContactInfo = false;
    
    // LinkedIn URL (always available)
    const linkedinUrl = document.getElementById('linkedin-url').querySelector('span:last-child');
    linkedinUrl.innerHTML = `<a href="${contactInfo.linkedinUrl || '#'}" target="_blank" style="color: white; text-decoration: underline;">View Profile</a>`;
    hasContactInfo = true;
    
    // Email
    if (contactInfo.email) {
        const emailInfo = document.getElementById('email-info');
        emailInfo.style.display = 'flex';
        emailInfo.querySelector('span:last-child').innerHTML = `<a href="mailto:${contactInfo.email}" style="color: white; text-decoration: underline;">${contactInfo.email}</a>`;
        hasContactInfo = true;
    }
    
    // Phone
    if (contactInfo.phone) {
        const phoneInfo = document.getElementById('phone-info');
        phoneInfo.style.display = 'flex';
        phoneInfo.querySelector('span:last-child').innerHTML = `<a href="tel:${contactInfo.phone}" style="color: white; text-decoration: underline;">${contactInfo.phone}</a>`;
        hasContactInfo = true;
    }
    
    // Websites
    if (contactInfo.websites && contactInfo.websites.length > 0) {
        const websitesInfo = document.getElementById('websites-info');
        const websitesList = document.getElementById('websites-list');
        websitesInfo.style.display = 'flex';
        
        const websiteLinks = contactInfo.websites.map(url => {
            try {
                const domain = new URL(url).hostname.replace('www.', '');
                return `<a href="${url}" target="_blank" style="color: white; text-decoration: underline; font-size: 12px; margin-right: 10px;">${domain}</a>`;
            } catch (e) {
                return `<a href="${url}" target="_blank" style="color: white; text-decoration: underline; font-size: 12px; margin-right: 10px;">${url}</a>`;
            }
        }).join('');
        
        websitesList.innerHTML = websiteLinks;
        hasContactInfo = true;
    }
    
    // Social Links
    if (contactInfo.socialLinks && Object.keys(contactInfo.socialLinks).length > 0) {
        const socialInfo = document.getElementById('social-info');
        const socialList = document.getElementById('social-list');
        socialInfo.style.display = 'flex';
        
        const socialLinks = Object.entries(contactInfo.socialLinks).map(([platform, url]) => {
            const emoji = {
                'twitter': '🐦',
                'github': '⚡',
                'instagram': '📸',
                'facebook': '👥',
                'youtube': '📺',
                'behance': '🎨',
                'dribbble': '🏀'
            }[platform] || '🔗';
            
            return `<a href="${url}" target="_blank" style="color: white; text-decoration: underline; font-size: 12px; margin-right: 10px;" title="${platform}">${emoji} ${platform}</a>`;
        }).join('');
        
        socialList.innerHTML = socialLinks;
        hasContactInfo = true;
    }
    
    // Company domain estimation
    if (contactInfo.companyDomain) {
        const companyDomain = document.getElementById('company-domain');
        companyDomain.style.display = 'flex';
        companyDomain.querySelector('span:last-child').textContent = `Possible company email: @${contactInfo.companyDomain}`;
        hasContactInfo = true;
    }
    
    // Show contact section if we have any contact info
    if (hasContactInfo) {
        contactSection.style.display = 'block';
    }
}

// Advanced contact extraction function
function extractAdvancedContact() {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        const currentTab = tabs[0];
        
        if (!currentTab.url.includes('linkedin.com/in/')) {
            alert('Please navigate to a LinkedIn profile page first.');
            return;
        }
        
        // Inject the advanced contact extractor
        chrome.scripting.executeScript({
            target: { tabId: currentTab.id },
            files: ['contact-extractor.js']
        }).then(() => {
            // Send message to extract advanced contact info
            chrome.tabs.sendMessage(currentTab.id, { action: 'extractAdvancedContact' }, function(response) {
                if (response && response.success) {
                    // Merge with existing data
                    chrome.storage.local.get(['linkedinProfileData'], function(result) {
                        const existingData = result.linkedinProfileData || {};
                        existingData.contactInfo = { ...existingData.contactInfo, ...response.contactInfo };
                        
                        chrome.storage.local.set({ linkedinProfileData: existingData });
                        displayProfileData(existingData);
                    });
                } else {
                    alert('Could not extract additional contact information. LinkedIn may have privacy restrictions.');
                }
            });
        }).catch(error => {
            console.error('Failed to inject contact extractor:', error);
        });
    });
}